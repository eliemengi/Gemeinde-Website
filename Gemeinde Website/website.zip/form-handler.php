<?php 
 $name = $_POST['name'];
 $visitor_email = $_POST['email'];
 $subject = $_POST['subject'];
 $message = $_POST['message'];

 $email_form = 'info@qdl-karlsruhe.de';
 $email_subject = 'New Form Submission';
 $email_body = "User Name: $name\n".
               "User Email: $visitor_email\n".
               "Subject: $subject\n".
               "message: $message\n";

    $to =  'qdeslebens@gmail.com';
    $headers = "From: $email_body-from \r\n";  
    $headers .= "Reply-To: $visitor_email \r\n"; 
    mail($to,$email_subject,$email_body,$headers);
    header("Location: Contact.html");
    
?>

